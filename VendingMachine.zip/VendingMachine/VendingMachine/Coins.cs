﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
  public static  class Coins
    {

        public const double nickle = 0.05;
        public const double dimes = 0.1;
        public const double quarter = 0.25;


        public static string GetCoins(double code)
        {
            foreach (var field in typeof(Coins).GetFields())
            {
                if ((double)field.GetValue(null) == code)
                    return field.Name.ToString();
            }
            return "";
        }
        
    }
}
