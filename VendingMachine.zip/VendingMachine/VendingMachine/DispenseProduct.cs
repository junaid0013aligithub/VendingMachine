﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
   public static class DispenseProduct
    {
        public const double cola = 1;
        public const double chips = 0.5;
        public const double candy = 0.65;

        public static double GetProductPrice(string name)
        {
           double val= (double)typeof(DispenseProduct).GetField(name).GetValue(null);
            return val;

        }


    }
}
