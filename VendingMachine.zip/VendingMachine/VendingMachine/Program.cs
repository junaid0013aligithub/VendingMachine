﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine
{
    class Program
    {
        public static double amount = 0;
        public static double tot_amount = 0;
        public static string message = "";
        static void Main(string[] args)
        {

            Console.WriteLine("1.Add Money 2.Show Product 0.Exit");
            string line = "0";
            while ((line = Console.ReadLine()) != "0")
            {
                if (line == "1" || line == "2")
                {
                    Program.FirstRun(line);
                }
                string amnt_avlbl = "Available Amount : $" + tot_amount.ToString();
                Console.WriteLine(amnt_avlbl);
                Console.WriteLine("1.Add Money 2.Show Product 0.Exit");

            }


        }


        public static void swicthcase(char ch)
        {
            switch (Char.ToLower(ch))
            {
                case '1':
                    message = Program.AddMoney(out amount);
                    Console.WriteLine(message);

                    Console.ReadLine();
                    break;
                case '2':
                    Program.displayproductmessage();
                    break;
                default:
                    Console.WriteLine("Not a Valid Input");
                    break;
            }

        }


        public static void FirstRun(string line)
        {


            char ch;
            ch = Convert.ToChar(line);
            Program.swicthcase(ch);

            Console.ReadLine();


        }

        public static string AddMoney(out double amount)
        {
            string message = "";
            amount = 0;
            Console.WriteLine("Please Enter Height");
            var in_height = Console.ReadLine();
            int int_height;
            if (!int.TryParse(in_height, out int_height))
            {
                message = "Invalid Height";

            }
            string height = ConfigurationManager.AppSettings["height"];
            IList<string> arr_height = height.Split(new string[] { ",", " " }, StringSplitOptions.RemoveEmptyEntries);
            if (!arr_height.Contains(in_height))
            {

                message = "Invalid Height";
                return message;
            }
            Console.WriteLine("Please Enter Weight");
            var in_weigth = Console.ReadLine();
            int int_weigth;
            if (!int.TryParse(in_weigth, out int_weigth))
            {
                message = "Invalid Weight";
                return message;

            }
            string weight = ConfigurationManager.AppSettings["weight"];
            IList<string> arr_weight = weight.Split(new string[] { ",", " " }, StringSplitOptions.RemoveEmptyEntries);
            if (!arr_weight.Contains(in_weigth))
            {

                message = "Invalid Weight";
                return message;
            }
            double amount1 = (double)int_height / int_weigth;
            string isvalidcoin = Coins.GetCoins(amount1);
            if (isvalidcoin == "")
            {
                message = "Invalid Coin";
                return message;

            }

            amount = amount1;
            tot_amount = tot_amount + amount;
            message = isvalidcoin + " Added";
            return message;

        }


        public static void displayproductmessage()
        {
            Console.WriteLine("1.Cola 2.Chips 3.Candy");
            string s = Console.ReadLine();
            string productname = "";
            if(s=="1")
            {
                productname = "cola";
            }
            if (s == "2")
            {
                productname = "chips";
            }
            if (s == "3")
            {
                productname = "candy";
            }
            if (productname != "")
            {
                Program.dispense(productname);
            }
        }

        public static void dispense (string productname)
            {
            double productprice = DispenseProduct.GetProductPrice(productname);
            if(tot_amount < productprice)
            {
                Console.WriteLine("Insufficient Amount");
                 Console.ReadLine();
            }
            else
            {
                tot_amount = tot_amount - productprice;
                Console.WriteLine(productname);
                Console.WriteLine("Thank You");
                Console.ReadLine();
            }
            }

    }
}
